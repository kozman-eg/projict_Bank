﻿#include <iostream>
#include <windows.h> // مخصصة للتحكم بموقع المؤشر والألوان
#include <conio.h>   // مخصصة للالتقاط الفوري للأسهم عبر _getch()

using namespace std;

// دالة التحكم بموقع مؤشر الكتابة على الشاشة (X: عمود، Y: سطر)
void gotoxy(int x, int y) {
    COORD coord;
    coord.X = x;
    coord.Y = y;           
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

// دالة لمسح سطر معين بالكامل لتنظيف مكان الإدخال السفلي
void clearLine(int y, int x = 0) {

    gotoxy(x, y);
    cout << "                                                                    "; // مساحات فارغة للمسح
}
// دالة مخصصة لمسح سطر القائمة قبل إعادة طباعته لمنع تداخل الحروف عند الإزاحة
void clearMenuLine(int y) {
    gotoxy(10, y); // تبدأ المسح من قبل العمود 15 بقليل
    cout << "                                                                 ";
}

int main() {
    // إعداد الخيارات المتوفرة في القائمة
    string menu_items[] = { "Username:", "Email:", "Password:", "Country:" ,"ggggg", "Register", "Back" };
    int total_items = 7;
    int selected_index = 0; // الخيار الذي يقف عليه السهم حالياً

    // قيم نصية لتخزين ما يدخله المستخدم لاحقاً
    string username = "";
    string email = "";
    string password = "";
    string country = "";
    string ggggg = "";

    // 1. طباعة الهيكل الثابت للقائمة أول مرة فقط
    cout << "##################################################" << endl;
    cout << "                     Sign Up                      " << endl;
    cout << "##################################################" << endl;

    while (true) {
        // 2. تحديث طباعة الخيارات وبياناتها في مواقعها الثابتة
        for (int i = 0; i < total_items; i++) {

            if (i < (int)(total_items / 2))
            {

                // 1. مسح مكان السطر القديم أولاً لتجنب تشوه الحروف أثناء الحركة
                clearMenuLine(8 + i);
                // 2. تطبيق معادلة الإزاحة الذكية
                    if (i == selected_index) {
                        // إذا كان العنصر محدداً: نزاح بمقدار 5 خطوات لليمين/الداخل (العمود 20)
                        gotoxy(15, 8 + i);
                        cout << "> " << menu_items[i];
                    }
                    else {
                        // إذا كان غير محدد: يطبع في مكانه الطبيعي الثابت (العمود 15)
                        gotoxy(20, 8 + i);
                        cout << "  " << menu_items[i];
                    }

            }else 
            {

                // 1. مسح مكان السطر القديم أولاً لتجنب تشوه الحروف أثناء الحركة
                clearMenuLine(50 + i);
                // 2. تطبيق معادلة الإزاحة الذكية
                if (i == selected_index) {
                    // إذا كان العنصر محدداً: نزاح بمقدار 5 خطوات لليمين/الداخل (العمود 20)
                    gotoxy(50, 5 + i);
                    cout << "> " << menu_items[i];
                }
                else {
                    // إذا كان غير محدد: يطبع في مكانه الطبيعي الثابت (العمود 15)
                    gotoxy(55, 5 + i);
                    cout << "  " << menu_items[i];
                }


            }

           
            // طباعة المدخلات بجانب العناوين الخاصة بها إذا كانت مكتوبة
            if (i == 0) cout << " " << username;
            if (i == 1) cout << " " << email;
            if (i == 2) cout << " " << password;
            if (i == 3) cout << " " << country;
            if (i == 4) cout << " " << ggggg;
        }

        // 3. قراءة حركة المستخدم من الكيبورد فوراً
        int key = _getch();

        if (key == 224) { // إذا ضغط المستخدم على أحد الأسهم
            key = _getch(); // نقرأ القيمة الثانية لتحديد الاتجاه

            if (key == 72) { // سهم لأعلى
                selected_index--;
                if (selected_index < 0) selected_index = total_items - 1; // دوران للقائمة
            }
            else if (key == 80) { // سهم لأسفل
                selected_index++;
                if (selected_index >= total_items) selected_index = 0; // دوران للقائمة
            }
        }
        else if (key == 13) { // إذا ضغط المستخدم زر Enter لاختيار الخيار الحالي

            // شاشة الإدخال المنفصلة أسفل القائمة (السطر 14)
            if (selected_index == 0) { // اختيار Username
                clearLine(14);
                gotoxy(26, 8 + selected_index);
                cout << "Enter Username: ";
                cin >> username;
                clearLine(14); // مسح السطر السفلي بعد الانتهاء ليظل المظهر نظيفاً
            }
            else if (selected_index == 1) { // اختيار Email
                clearLine(14);
                gotoxy(26, 8 + selected_index);
                cout << "Enter Email: ";
                cin >> email;
                clearLine(14);
            }
            else if (selected_index == 2) { // اختيار Password
                clearLine(14);
                gotoxy(26, 8 + selected_index);
                cout << "Enter Password: ";
                cin >> password;
                clearLine(14);
            }
            else if (selected_index == 3) { // اختيار Country
                clearLine(14);
                gotoxy(65, 5 + selected_index);
                cout << "Enter Country: ";
                cin >> country;
                clearLine(14);
            }
            else if (selected_index == 4) { // زر Register
                clearLine(14);
                gotoxy(65, 5 + selected_index);
                cout << "Enter Country: ";
                cin >> ggggg;
                clearLine(14);
            }
            else if (selected_index == 5) { // زر Register
                clearLine(14);
                gotoxy(65, 14);
                cout << "Registration Successful! Press any key to continue...";
                _getch();
                break; // الخروج من الشاشة
            }
            else if (selected_index == 6) { // زر Back
                clearLine(14);
                break;
            }
        }
    }

    return 0;
}
